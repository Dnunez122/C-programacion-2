﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Referencia capa BLL
using BLL;

namespace AppPuntoVenta
{
    public partial class FrmLogin : Form
    {

        //Variable tipo Object
        private Usuario objUsuario = null;

      public FrmLogin()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            //se pregunta al usuario si desea salir del sistema
            if (MessageBox.Show("Desea salir del sistema","Confirmar",
                MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit(); // se finaliza la aplicación
            }
        }

        private bool IntentoAutenticacion()
        {
            try
            {
                //variable local 
                bool autorizado = false;

                //se instancia el objeto usuario
                objUsuario = new Usuario();

                //se rellena el object con los datos del front-end
                objUsuario.Login = txtUsuario.Text.Trim();
                objUsuario.Password = txtPassword.Text.Trim();

                if (objUsuario.Login.Equals("admin") && objUsuario.ConfirmarPassword("admin"))
                {
                    autorizado = true;
                }
                return autorizado;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            try
            {
                if (IntentoAutenticacion() )
                {
                    Close();
                }
                else
                {
                    throw new Exception("Usuario o password incorrectos...");
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

    } //cierre formulario
} //cierre namespaces
