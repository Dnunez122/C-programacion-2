﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;


namespace AppVuelosCR
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //se cierra la app
            Environment.Exit(0);
        }


        // 
        
        private void BotonTarifa_Click(object sender, EventArgs e)
        {
            try
            {
                var cliente = new Cliente
                {
                    //se establece el valor de las variables de las textbox
                    Cedula = textBoxCedula.Text,
                    Nombre = textBoxNombre.Text,
                };
                var Tiquete = new Tiquete
                {
                    //Lo mismo que arriba pero con el destino y aerolinea
                    Cliente = cliente,
                    Destino = comboBoxDestinos.SelectedItem.ToString(),
                    Aerolinea = comboBoxAerolinea.SelectedItem.ToString(),
                };
                //Se calcula el precio final con los metodos de el objeto tiquete y se imprime en el label.
                decimal precioBase = ObtenerPrecioDestino(Tiquete.Destino);
                decimal precioFinal = Tiquete.CalcularPrecioFinalTiquete(precioBase);
                labelPrecioFinal.Text = $"El precio final del tiquete es : ${precioFinal}";


            }
            catch
            {
                
            }
        }


        //precio por destino
        private decimal ObtenerPrecioDestino(string destino)
        {
            switch (destino)
            {
                case "Argentina": return 200m;
                case "Bolivia": return 250m;
                case "Brasil": return 325m;
                case "Chile": return 275m;
                case "Colombia": return 205m;
                case "Ecuador": return 230m;
                case "Guyana": return 270m;
                case "Nicaragua": return 120m;
                default: return 0m;
            }
        }

        //al darle click se activa el metodo imprimir 
        private void CompraYImpresion_Click(object sender, EventArgs e)
        {
            printDocument1 = new PrintDocument();

            PrinterSettings ps = new PrinterSettings();

            printDocument1.PrinterSettings = ps;

            printDocument1.PrintPage += Imprimir;

            printDocument1.Print();


        }


        //Metodo donde se imprime todo 
        private void Imprimir(object sender, PrintPageEventArgs e)
        {

            Font font = new Font("Arial", 14, FontStyle.Regular, GraphicsUnit.Point);



            e.Graphics.DrawString("Factura de compra de tiquete:", font, Brushes.Black, new RectangleF(10,10,200, 200));

            e.Graphics.DrawString(textBoxNombre.Text, font, Brushes.Black, new RectangleF(0, 100, 300, 200));

            e.Graphics.DrawString(textBoxCedula.Text, font, Brushes.Black, new RectangleF(0,140,200,200));

            e.Graphics.DrawString(comboBoxDestinos.Text, font, Brushes.Black, new RectangleF(0,160,200, 200));  

            e.Graphics.DrawString(comboBoxAerolinea.Text, font, Brushes.Black, new RectangleF(0,180,200, 201));   

            e.Graphics.DrawString(labelPrecioFinal.Text, font, Brushes.Black, new RectangleF(0,200, 200, 200));  
        
        }
    }
}
