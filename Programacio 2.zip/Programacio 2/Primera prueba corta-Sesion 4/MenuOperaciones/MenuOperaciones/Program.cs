﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MenuOperaciones
{
    using System;

    class Program
    {
        static void Main()
        {
            while (true) ///Usar un while para ver la opcion que ingresa el usuario
            {
                Console.WriteLine("\nMenú:");
                Console.WriteLine("1. Suma");
                Console.WriteLine("2. Resta");
                Console.WriteLine("3. Multiplicación");
                Console.WriteLine("4. División");
                Console.WriteLine("5. Potenciación");
                Console.WriteLine("6. Salir");

                Console.Write("Seleccione una opción (1-6): ");
                string opcion = Console.ReadLine();

                if (opcion == "6") ///si la opcion es 6 termina
                    break;

                double num1, num2;  ///declaro num1 y num2 como double 

                try  ///Para recibir casos excepcionales y rechazarlos o manejarlos 
                {
                    Console.Write("Ingrese el primer número: ");
                    num1 = Convert.ToDouble(Console.ReadLine());

                    Console.Write("Ingrese el segundo número: ");
                    num2 = Convert.ToDouble(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.WriteLine("Por favor, ingrese números válidos.");
                    continue;
                }

                double resultado = 0; ///Resultado como double 0 

                switch (opcion) ///Aqui es mas facil el switch, con los metodos
                {
                    case "1":
                        resultado = Suma(num1, num2);
                        break;
                    case "2":
                        resultado = Resta(num1, num2);
                        break;
                    case "3":
                        resultado = Multiplicacion(num1, num2);
                        break;
                    case "4":
                        resultado = Division(num1, num2);
                        break;
                    case "5":
                        resultado = Potenciacion(num1, num2);
                        break;
                    default:
                        Console.WriteLine("Opción no válida. Por favor, seleccione una opción del 1 al 6.");
                        continue;
                }

                Console.WriteLine("El resultado es: " + resultado);
            }
        }

        ///Metodos para mostrar resultados.
        
     
        static double Suma(double a, double b)
        {
            return a + b;
        }

        static double Resta(double a, double b)
        {
            return a - b;
        }

        static double Multiplicacion(double a, double b)
        {
            return a * b;
        }

        static double Division(double a, double b)
        {
            if (b != 0)
                return a / b;
            else
            {
                Console.WriteLine("No se puede dividir por cero.");
                return 0;
            }
        }

        static double Potenciacion(double a, double b)
        {
            return Math.Pow(a, b);
        }
    }

}
