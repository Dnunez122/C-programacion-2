﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppCalculador
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //pregunta 
            if (MessageBox.Show("Desea salir del programa.","confirmar",
                MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
            {
                //Si la repsuesta es yes
                Application.Exit();
            }

        }

     
        ///Boton cancelar
       
        private void button3_Click(object sender, EventArgs e)
        {
            this.LimpiarPantalla();

        }


        private void LimpiarPantalla()
        {
            this.TxtNumero1.Text = "0"; //se asigna un 0 para inicializar la caja de texto
            this.TxtNumero2.Text = "0";
            this.TxtResultado.Text = "0";
            

            //sintaxis para seleccionar un item por default 
            this.obxOperaciones.SelectedIndex = 0;
        }
    }
}
