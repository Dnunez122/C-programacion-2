﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App_sumatoria_mayor_promedio_menor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ///Declaramos variables.
            double num1 = 0;
            double num2 = 0;
            double num3 = 0;
            double resultado = 0;
            double sum = 0;
            double prom = 0;
            string dato = "";

            ///Pedimos datos y convertimos tipo de dato.
            Console.WriteLine("Ingrese el primer numero: ");
            dato = Console.ReadLine();
            num1 = double.Parse(dato);

            Console.WriteLine("Ingrese el segundo numero: ");
            dato = Console.ReadLine();
            num2 = double.Parse(dato);


            Console.WriteLine("Ingrese el tercer numero: ");
            dato = Console.ReadLine();
            num3 = double.Parse(dato);

            ///Declaramos los resultados
            resultado = num1 + num2 + num3;

            prom = (num1 + num2 + num3) / 3;

            sum = num1 + num2 + num3;   

            ///mostramos resultados.
            Console.WriteLine("El resultado de la suma de los tres numeros es: " + resultado);
            Console.WriteLine("La sumatoria de los tres numeros es: " + sum);
            Console.WriteLine("El promedio es: " + prom);

            ///Usamos if para ver que numero es mayor.
            if (num1 > num2 && num1 > num3  ) 
            {
                Console.WriteLine("El mayor es: " +num1);
            }
            else if (num2 > num1 && num2 > num3)
            {
                Console.WriteLine("El mayor es el: " +num2);

            }
            else
            {
                Console.WriteLine("El mayor es: " +num3);
            }




            ///usamos el if para ver cual es menor
            if (num1 < num2 && num1 < num3)
            {
                Console.WriteLine("El numero menor es:" + num1);

            }
            else if (num2 < num1 && num2 < num3)
            {
                Console.WriteLine("El numero menor es:" + num2);

            }
            else
            {
                Console.WriteLine("El numero menor es: " + num3);
            }
            
            ///terminamos la app
            Console.WriteLine("Presione cualquier tecla para terminar. ");
            Console.ReadKey();
            Environment.Exit(0);



        }
    }
}
