﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace SalarioExamenDiego

{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Instancia para hacer display de todo lo que esta en menu y asi que el codigo se ejecute lol xd
            Menu menu = new Menu();

            menu.MostrarMenu();
             
        }

    }
}
    