﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cuadrado_y_Cubo_de_el_numero
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ///Declaramos variables
            int num = 0;
            string dato = "";
            double Cuadrado = 0;
            double cubo = 0;

            ///Pedimos el numero y convertimos su tipo 
            Console.WriteLine("Ingrese el numero de el que desea saber si cuadrado y cubo: ");
            dato = Console.ReadLine();
            num = int.Parse(dato);


            /// elevamos al cubo y al cuadrado 
            Cuadrado = num * num;
            cubo = num * num * num;

            ///Mostramos resultados 

            Console.WriteLine("El cuadrado de este numero es: " + Cuadrado);
            Console.WriteLine("El cubo de este numero es:  " + cubo);


            ///Cerramos 
            Console.WriteLine("Presione cualquier tecla para salir ");
            Console.ReadKey();
            Environment.Exit(0);



        }
    }
}
