﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppCambioCliente
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ///Variables
            int pago = 0;
            int cambio = 0;
            int precio_producto = 0;
            string dato = "";


            ///Pedir info 
            Console.WriteLine("***Chino Diego***");

            Console.WriteLine("Ingrese el precio del producto: ");
            dato = Console.ReadLine();
            precio_producto = int.Parse(dato);


            Console.WriteLine("Ingrese con cuanto pago el cliente: ");
            dato = Console.ReadLine();
            pago = int.Parse(dato);

            cambio = pago - precio_producto;

            Console.WriteLine("El cambio es de: " + cambio);

            ///salir
            Console.WriteLine("Presione cualquier tecla para salir. ");
            Console.ReadKey();
            Environment.Exit(0);
        }
    }
}
