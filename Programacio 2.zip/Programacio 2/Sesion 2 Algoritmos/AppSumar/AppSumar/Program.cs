﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSumar
{
    internal class Program
    {
        /// <summary>
        /// Metodo main encargado de ejecutar todos los bloques de codigo del proyecto.
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        { 
            ///Declaracion de variables
            double num1 = 0;
            double num2 = 0;
            double result = 0;
            string dato = "";

            //entrada de datos 
            Console.WriteLine("***Aplicacion Sumar***");

            Console.WriteLine("Digite el primer numero: ");

            ///Almacenamiento de dato.
            dato = Console.ReadLine();

            ///Cambio de tipo de dato.
            num1 = double.Parse(dato);

            ///Solicitamos segundo numero 
            Console.WriteLine("Digite el segundo numero: ");

            dato = Console.ReadLine(); ///Se almacena y se lee
            num2 = double.Parse(dato); ///Se convierte a numero.  

            ///Se realiza la operacion.
            result = num1 + num2;

            ///Se muestra el resultado 
            Console.WriteLine("El total de la suma es: " +result);

            Console.WriteLine("Presione cualquier tecla para terminar. ");
            Console.ReadKey();
            Environment.Exit(0);


            ///Sintaxis del if 
            if (num1 > num2) 
            {
                Console.WriteLine("El primer numero es mayor ");

            }
            else if (num1 == num2) 
            {
                Console.WriteLine("Los numeros son iguales");
            }
           else
            {
                Console.WriteLine("El numero mayor es el segundo");
            } 

        }
    } ///Cierre class
} ///Cierre namespace
