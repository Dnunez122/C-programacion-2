﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppVuelosCR
{
    internal class Tiquete
    {
        //Atributos necesarios
        public Cliente Cliente { get; set; }
        public string Destino { get; set; }
        public string Aerolinea { get; set; }


        //se calcula el monto de serviocio partiendo de base las aerolinas que se van a utilizar, como parametro preciobase
        public decimal CalcularMontoServicio(decimal precioBase)
        {
            decimal porcentaje = 0m;
            switch (Aerolinea)
            {
                case "Avianca": porcentaje = 0.24m; break;
                case "Despegar": porcentaje = 0.18m; break;
                case "American Airlines": porcentaje = 0.32m; break;
                case "Japan Airlines": porcentaje = 0.25m; break;
                case "Qatar Airways": porcentaje = 0.27m; break;
            }
            return precioBase * porcentaje;
        }

        //Se usa el parametro "subtotal" para utilizarlo en el metodo con return con una simplem multiplicacion para que se añada el iba al subtotal
        public decimal CalcularMontoIVA(decimal subtotal)
        {
            return subtotal * 0.13m;
        }


        //Metodo calcular precio final con todas las operaciones correspondientes usando como parametro la variable precioBase
        public decimal CalcularPrecioFinalTiquete(decimal precioBase)
        {
            decimal servicio = CalcularMontoServicio(precioBase);
            decimal subtotal = precioBase + servicio;
            decimal iva = CalcularMontoIVA(subtotal);
            return subtotal + iva;
        }



        //Se obtiene el precio segun el destino selecicionado y se guarda en la variable destino. 
        public decimal ObtenerPrecioDestino(string destino)
        {
            switch (destino)
            {
                case "Argentina": return 200m;
                case "Bolivia": return 250m;
                case "Brasil": return 325m;
                case "Chile": return 275m;
                case "Colombia": return 205m;
                case "Ecuador": return 230m;
                case "Guyana": return 270m;
                case "Nicaragua": return 120m;
                default: return 0m;
            }
        }




    }
}
