﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppPuntoVenta
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            try
            {
                //se confirma al usuario si desea salir del sistema
                if (MessageBox.Show("Desea salir del sistema","Confirmar",
                    MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Application.Exit(); //se finaliza la aplicación
                }
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        } //cierre event

        private void Form1_Load(object sender, EventArgs e)
        {
            notifyIcon1.ShowBalloonTip(25); //Mostrar la notificación
            
            try
            {
                //se llama al método 
                MostrarLogin();
            }
            catch (Exception ex)
            {
                //Se muestra el error en caso que exista
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        //Método encargado de mostrar el formulario Login
        private void MostrarLogin()
        {
            try  //Se intenta mostrar el formulario
            {
                //se declara e intancia el formulario login
                FrmLogin frm = new FrmLogin();

                //se muestra el formulario de forma exclusiva
                frm.ShowDialog();

                //se liberan los recurso al cerrar el formulario
                frm.Dispose();
            }
            catch (Exception ex) //en caso de un erro se captura el exception
            {

                throw ex;//Se realiza el retorno del error
            }
        }

    } //cierre formulario
} //cierre namespaces
