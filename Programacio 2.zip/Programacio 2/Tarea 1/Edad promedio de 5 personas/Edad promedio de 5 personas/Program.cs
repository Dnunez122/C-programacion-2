﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Edad_promedio_de_5_personas
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ///Declaramos variables.
            int edad1 = 0;
            int edad2 = 0;
            int edad3 = 0;
            int edad4 = 0;
            int edad5 = 0;
            int promedio = 0;
            string dato = "";

            ///Pedimos la edad de las cinco personas y les cambiamos el tipo.
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Digite la edad de la persona: ");
                dato = Console.ReadLine();

                switch (i)
                {
                    case 0:
                        edad1 = int.Parse(dato);
                        break;
                    case 1:
                        edad2 = int.Parse(dato);  
                        break;
                    case 2: 
                        edad3 = int.Parse(dato);  
                        break;
                    case 3:
                        edad4 = int.Parse(dato);
                        break;
                    case 4:
                        edad5 = int.Parse(dato);  
                        break;
                }
                    


            }
          
            ///Definimos promedio.
            promedio = (edad1 + edad2 + edad3 + edad4 + edad5) / 5;

            ///Mostramos resultados
            Console.WriteLine("El promedio de edad es: " + promedio);

            ///Cerramos app
            Console.WriteLine("Presione cualquier tecla para cerrar. ");
            Console.ReadKey();
            Environment.Exit(0);
        }
    }
}
