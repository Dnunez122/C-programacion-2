﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rectangulo__Area__Perimetro
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ///Declaramos  variables.
            double altura = 0;
            double bases = 0;
            double result_perim = 0;
            double result_area = 0;
            string dato = "";

            ///Pedimos info.
            Console.WriteLine("Ingrese la altura del rectangunlo: ");
            dato = Console.ReadLine();
            altura = double.Parse(dato);

            Console.WriteLine("Ingrese la base del rectangunlo: ");
            dato = Console.ReadLine();
            bases = double.Parse(dato);


            ///Declaramos resultados.
            result_perim = 2 * (bases + altura);

            result_area = bases * altura;


            ///Mostramos resultados.
            Console.WriteLine("El perimetro de el rectangulo es de: " + result_perim);
            Console.WriteLine("La area de el rectangulo es de: " + result_area);

            ///Cerramos 
            Console.WriteLine("Presione una tecla para salir. " );
            Console.ReadKey();
            Environment.Exit(0);
        }
    }
}
