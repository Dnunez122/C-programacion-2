﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;




namespace SistemaBancario
{
    public class CuentaBancaria
    {
        public string NumeroCuenta { get; set; }
        public string NombreCliente { get; set; }
        public int Saldo { get; set; }
        public string TelefonoCliente { get; set; }

        public CuentaBancaria(string numeroCuenta, string nombreCliente, int saldo, string telefonoCliente)
        {
            NumeroCuenta = numeroCuenta;
            NombreCliente = nombreCliente;
            Saldo = saldo;
            TelefonoCliente = telefonoCliente;
        }
    }

    public class MenuCuentaBancaria
    {
        private CuentaBancaria cuenta;

        public MenuCuentaBancaria(CuentaBancaria cuenta)
        {
            this.cuenta = cuenta;
        }

        public void MostrarMenu()
        {
            int opcion;

            do
            {
                Console.WriteLine("Escoja una opción:");
                Console.WriteLine("1. Retiro de efectivo");
                Console.WriteLine("2. Depósito en la cuenta");
                Console.WriteLine("3. Modificar teléfono del cliente");
                Console.WriteLine("4. Mostrar información del cliente");
                Console.WriteLine("5. Salir");

                if (int.TryParse(Console.ReadLine(), out opcion))
                {
                    ProcesarOpcion(opcion);
                }
                else
                {
                    Console.WriteLine("Opción no válida. Por favor, ingrese un número.");
                }

            } while (opcion != 5);
        }

        private void ProcesarOpcion(int opcion)
        {
            switch (opcion)
            {
                case 1:
                    RealizarRetiro();
                    break;
                case 2:
                    RealizarDeposito();
                    break;
                case 3:
                    ModificarTelefono();
                    break;
                case 4:
                    MostrarInformacionCliente();
                    break;
                case 5:
                    Console.WriteLine($"Cerrando la cuenta número {cuenta.NumeroCuenta} del cliente {cuenta.NombreCliente}");
                    break;
                default:
                    Console.WriteLine("Opción no válida. Por favor, ingrese un número del 1 al 5.");
                    break;
            }
        }

        private void RealizarRetiro()
        {
            Console.WriteLine("Ingrese la cantidad a retirar:");
            if (int.TryParse(Console.ReadLine(), out int cantidadRetiro))
            {
                if (cantidadRetiro > 0 && cantidadRetiro <= cuenta.Saldo)
                {
                    cuenta.Saldo -= cantidadRetiro;
                    Console.WriteLine($"Retiro exitoso. Nuevo saldo: {cuenta.Saldo} colones");
                }
                else
                {
                    Console.WriteLine("Cantidad no válida o insuficiente saldo.");
                }
            }
            else
            {
                Console.WriteLine("Cantidad no válida. Por favor, ingrese un número.");
            }
        }

        private void RealizarDeposito()
        {
            Console.WriteLine("Ingrese la cantidad a depositar:");
            if (int.TryParse(Console.ReadLine(), out int cantidadDeposito) && cantidadDeposito > 0)
            {
                cuenta.Saldo += cantidadDeposito;
                Console.WriteLine($"Depósito exitoso. Nuevo saldo: {cuenta.Saldo} colones");
            }
            else
            {
                Console.WriteLine("Cantidad no válida. Por favor, ingrese un número mayor a 0.");
            }
        }

        private void ModificarTelefono()
        {
            Console.WriteLine("Ingrese el nuevo número de teléfono:");
            string nuevoTelefono = Console.ReadLine();
            cuenta.TelefonoCliente = nuevoTelefono;
            Console.WriteLine("Teléfono modificado exitosamente.");
        }

        private void MostrarInformacionCliente()
        {
            Console.WriteLine($"Número de cuenta: {cuenta.NumeroCuenta}");
            Console.WriteLine($"Nombre del cliente: {cuenta.NombreCliente}");
            Console.WriteLine($"Teléfono: {cuenta.TelefonoCliente}");
            Console.WriteLine($"Saldo: {cuenta.Saldo} colones");
        }
    }

    public class PrincipalCuentaBancaria
    {
        public static void Main()
        {
            CuentaBancaria cuenta = new CuentaBancaria("123456789", "Juan Perez", 100000, "123456789");
            MenuCuentaBancaria menu = new MenuCuentaBancaria(cuenta);
            menu.MostrarMenu();
        }
    }
}
