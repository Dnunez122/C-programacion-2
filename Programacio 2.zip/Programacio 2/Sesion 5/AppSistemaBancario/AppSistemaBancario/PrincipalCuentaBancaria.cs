﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSistemaBancario
{
    public class PrincipalCuentaBancaria
    {
        //Variable tipo object
        private MenuCuentaBancaria objMenuCuentaCanc;

        //Contrusctor /ctor inicializa los atributos del objeto
        public PrincipalCuentaBancaria()
        {
            //Siempre se debe intanciar la variables de tipo object
            objMenuCuentaCanc = new MenuCuentaBancaria();
        }


    }
}
