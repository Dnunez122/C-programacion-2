﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalarioExamenDiego
{
    internal class Empleado
    {

        public int HorasTrabajadas { get; set; }

        public int PrecioHoras { get; set; }

        public int HorasExtra { get; set; }

        public int PrecioHorasExtra { get; set; }


        public Empleado()
        {
            HorasTrabajadas = 0;
            PrecioHoras = 0;
            HorasExtra = 0;
            PrecioHorasExtra = 0;
        }

        public void ObtenerSalarioBrutoYNeto()
        {

            // Solicita las horas trabajadas al usuario
            Console.WriteLine("Ingrese las horas trabajadas:");
            int horasTrabajadasInput = int.Parse(Console.ReadLine());

            // Solicita las horas extra trabajadas al usuario
            Console.WriteLine("Ingrese las horas extra trabajadas:");
            int horasExtraInput = int.Parse(Console.ReadLine());

            //Establecemos precio de las horas
            int precioHoras = 1800;

            //Y de las horas extra
            double precioHorasExtra = 2700;

            //operaciones matematicas para obtener salario bruto
            double salarioPorHorasTrabajadas = horasTrabajadasInput * precioHoras;
            double salarioPorHorasExtra = horasExtraInput * precioHorasExtra;
            double salarioBruto = salarioPorHorasTrabajadas + salarioPorHorasExtra;


            //Se muestra cantidad de paga por horas extra
            Console.WriteLine("El salario por horas extra es de: " + salarioPorHorasExtra);


            //Se muestra el salario bruto 
            Console.WriteLine("Salario bruto: " + salarioBruto);


            //Declaracion deducciones
            double Deduccion = 0;


            //Usamos la comprobacion if para determinar el valor de la deduccion yupiii
            if (salarioBruto <= 250000)
            {
                //Declaramos y mostramos salario neto
                double MontoDeduccion = salarioBruto * 0.09;
                double salarioNeto = salarioBruto - MontoDeduccion;
                Console.WriteLine("Su Salario Neto es de: " + salarioNeto);
                Console.WriteLine("El monto de la deduccion es: " + MontoDeduccion);


            } else if (salarioBruto <= 380000 )
            {
                //Declaramos y mostramos salario neto
                double MontoDeduccion = salarioBruto * 0.12;
                double salarioNeto = salarioBruto - MontoDeduccion;
                Console.WriteLine("Su Salario Neto es de: " + salarioNeto);
                Console.WriteLine("El monto de la deduccion es: " + MontoDeduccion);


            } else if (salarioBruto > 380000)
            {
                //Declaramos y mostramos salario neto
                double MontoDeduccion = salarioBruto * 0.15;
                double salarioNeto = salarioBruto - MontoDeduccion;
                Console.WriteLine("Su Salario Neto es de: " + salarioNeto);
                Console.WriteLine("El monto de la deduccion es: " + MontoDeduccion);


            }



            




        }

      




    }
}

