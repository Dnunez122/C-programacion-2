﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSalarioMensual___denuevo
{
    internal class Program
    {
        static void Main(string[] args)
        {

            ///variable 
            float cantHoras = 0;
            float precioHora = 0;
            double carga_social = 0;
            float montoAsociacion = 0;
            float salario_semana = 0;
            float salario_mensual = 0;
            ///Mensaje bienvenida 
            ///

            Console.WriteLine("***Aplicacion calcular salario mensual ****");


            ///solicitud de datos- sintaxis loop- varios tipo do/while (1 vez), while , for
            ///Do while
            ///Tenemos q tener una variable de control 
            char opcion = 'S';
            do
            {
                Console.WriteLine("Digite la cantidad de hora trabajadas por semana: ");
                cantHoras = float.Parse(Console.ReadLine());

                    ///Solicitud de precio por hora 
                Console.WriteLine("Digite el precio por hora: ");
                precioHora = float.Parse(Console.ReadLine());


                salario_semana = (cantHoras * precioHora);
                salario_mensual = (salario_semana * float.Parse ("4,2"));
                carga_social = (salario_mensual * (float)(10.5 / 100));
                montoAsociacion = (salario_mensual * ((float )(5 / 100)));

                salario_mensual = ((float)(salario_mensual - carga_social));
                salario_mensual = (salario_mensual - montoAsociacion);

                ///resultado
                Console.WriteLine($" el salario mensual es {salario_mensual}" +
                    $" \n"" 



                ///Preguntar si desea continuar
                Console.WriteLine("Si desea realizar otro calculo presiones S ");
                ///se toma siempre la primera letra del texto escrito en la consola
                opcion = char.Parse(Console.ReadLine().ToUpper().Substring(0, 1));



            } while (opcion == 'S'); ///Funciona si la condicion es verdadera

           
            ///finalizar app
            Console.WriteLine("Presione cualquier tecla para terminar");
            Console.ReadKey();
            Environment.Exit(0);






        }
    }
}
