﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Primer_Algoritmo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ///Declaramos variables
            int num1 = 0;
            int num2 = 0;
            int resultsuma = 0;
            double resulttotal = 0;
            string dato = "";

            ///Pedimos primer numero
            Console.WriteLine("Ingrese el primer numero para la ecuacion: ");
            dato = Console.ReadLine();
            num1 = int.Parse(dato);

            ///Pedimos segundo numero               
            Console.WriteLine("Ingrese el segundo numero para la ecuacion: ");
            dato = Console.ReadLine();
            num2 = int.Parse(dato);

            ///Definimos resultados y numero a elevar.,
            resultsuma = num1 + num2;
            resulttotal = resultsuma * resultsuma  / 3;


            ///Mostramos el resultado
            Console.WriteLine("El resultado de la operacion es: " + resulttotal);

            ///cerramos la app
            Console.WriteLine("Presione cualquier tecla para salir ");
            Console.ReadKey();
            Environment.Exit(0);
        }
    }
}
