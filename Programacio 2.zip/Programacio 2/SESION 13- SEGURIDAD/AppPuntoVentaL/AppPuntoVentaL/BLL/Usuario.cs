﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class Usuario
    {
        public string Login { get; set; }

        public string NombreCompleto { get; set; }

        public string Password { get; set; }

        public DateTime FechaRegistro { get; set; }

        public char Estado { get; set; }

        public bool ConfirmarPassword(string pw)
        {
            bool confirmado = false; //Variable local solo existe dentro del método

            if ( ! string.IsNullOrEmpty(pw)) //se validad que no esté en blanco
            {
                if (Password.Equals(pw)) //se realiza la comparación del texto por medio del Equals( )
                {
                    confirmado = true;  //se indica que el password es correcto
                }
            }
            return confirmado;  
        }

    } //cierre class
} //cierre namespaces
