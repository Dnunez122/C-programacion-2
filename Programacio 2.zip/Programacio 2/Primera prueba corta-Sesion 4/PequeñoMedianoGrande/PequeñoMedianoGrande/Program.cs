﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



   

namespace PequenoMedianoGrande
{
        internal class Program
        {
            static void Main(string[] args)
            {
                // Variables
                int[] numeros = new int[6]; //Array de ints enteros 
                int promedio = 0;

                // Entrada de datos
                for (int i = 0; i < 6; i++)  /// for para hacerlo mas rapido
                {
                    Console.Write("Ingresa el número que quieres evaluar: ");
                    string dato = Console.ReadLine();   ///Se mete el dato en string 

                    if (!int.TryParse(dato, out numeros[i]))    ///si lo ingresado es un int se mete al array sino 
                    {
                        Console.WriteLine("Por favor, ingresa un número válido."); ///Se imprime esto 
                        i--;
                    }
                }

                // Cálculo del promedio
                foreach (int numero in numeros) ///Para cada int numero en numeros  (osea lo recorre)
                {
                    promedio += numero;  ///se va sumando la varibable y se almacena 
                }
                promedio /= 6; ///se divide y se saca promedio

                // Encontrar el número mayor
                int maximo = numeros[0];

                foreach (int numero in numeros) ///recorre el array y el mas grande se almacena en maximo 
                {
                    if (numero > maximo)
                    {
                        maximo = numero;
                    }
                }

            // Encontrar el número menor
            int minimo = numeros[0];

            foreach (int numero in numeros)
            {
                if (numero < minimo)
                {
                    minimo = numero;
                }
            }

            // Mostrar resultados
            Console.WriteLine("El promedio es: " + promedio);
            Console.WriteLine("El número mayor es: " + maximo);
            Console.WriteLine("El número menor es: " + minimo);
        }
        }
}

















   

