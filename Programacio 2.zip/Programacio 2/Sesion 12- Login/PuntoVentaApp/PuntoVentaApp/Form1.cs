﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//referencia capa bll
using BLL;
namespace PuntoVentaApp
{
    public partial class Form1 : Form
    {


    
        public Form1()
        {
            InitializeComponent();
        }

     
    

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            try
            {
                //se confima al usuario si desea salir del sistema 
                if (MessageBox.Show("Desea salir del sistema", "confirmar ",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Application.Exit();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            notifyIcon1.ShowBalloonTip(25); //mostramos el notify 

            try
            {
                //Se llama al metodo 
                MostrarLogin();
            }
            catch (Exception ex)
            {
                //Se muestra el error en caso que exista
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Metodo encargado de mostrar el formulario Login
        public void MostrarLogin()
        {
            try  //se intenta mostrar el formulario
            {
                //se declara e intancia el formulario en el login
                FRNLogin frm = new FRNLogin();

                //Se muestra el formulario
                frm.ShowDialog();

                //Se liberan los recursos al cerrar el formulario
                frm.Dispose();



            }
            catch (Exception ex) //En caso de un error se captura en el exception
            {

                throw ex; //Se realiza el retorno del error 
            }
        }


    }
}
