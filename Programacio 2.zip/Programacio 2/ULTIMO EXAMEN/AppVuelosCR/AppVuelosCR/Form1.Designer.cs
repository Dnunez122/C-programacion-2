﻿namespace AppVuelosCR
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.labelPrecioFinal = new System.Windows.Forms.Label();
            this.textBoxCedula = new System.Windows.Forms.TextBox();
            this.textBoxNombre = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CompraYImpresion = new System.Windows.Forms.Button();
            this.BotonTarifa = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.comboBoxAerolinea = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxDestinos = new System.Windows.Forms.ComboBox();
            this.button3 = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Tan;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-2, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1131, 165);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(197, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(677, 64);
            this.label1.TabIndex = 0;
            this.label1.Tag = "Bienvenido a VuelosCR";
            this.label1.Text = "Bienvenido a VuelosCR";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Beige;
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Location = new System.Drawing.Point(22, 183);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1063, 931);
            this.panel2.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.labelPrecioFinal);
            this.groupBox1.Controls.Add(this.textBoxCedula);
            this.groupBox1.Controls.Add(this.textBoxNombre);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.CompraYImpresion);
            this.groupBox1.Controls.Add(this.BotonTarifa);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.comboBoxAerolinea);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.comboBoxDestinos);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(36, 21);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(987, 893);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Opciones de Destinos y Aerolineas";
            // 
            // labelPrecioFinal
            // 
            this.labelPrecioFinal.AutoSize = true;
            this.labelPrecioFinal.Location = new System.Drawing.Point(30, 793);
            this.labelPrecioFinal.Name = "labelPrecioFinal";
            this.labelPrecioFinal.Size = new System.Drawing.Size(528, 41);
            this.labelPrecioFinal.TabIndex = 11;
            this.labelPrecioFinal.Text = "Presione el boton para tarifa final.";
            // 
            // textBoxCedula
            // 
            this.textBoxCedula.Location = new System.Drawing.Point(319, 220);
            this.textBoxCedula.Name = "textBoxCedula";
            this.textBoxCedula.Size = new System.Drawing.Size(252, 48);
            this.textBoxCedula.TabIndex = 10;
            // 
            // textBoxNombre
            // 
            this.textBoxNombre.Location = new System.Drawing.Point(302, 117);
            this.textBoxNombre.Name = "textBoxNombre";
            this.textBoxNombre.Size = new System.Drawing.Size(295, 48);
            this.textBoxNombre.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 220);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(293, 41);
            this.label5.TabIndex = 8;
            this.label5.Text = "Cedula del cliente:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(290, 41);
            this.label4.TabIndex = 7;
            this.label4.Text = "Nombre completo:";
            // 
            // CompraYImpresion
            // 
            this.CompraYImpresion.BackColor = System.Drawing.Color.Wheat;
            this.CompraYImpresion.Location = new System.Drawing.Point(621, 570);
            this.CompraYImpresion.Name = "CompraYImpresion";
            this.CompraYImpresion.Size = new System.Drawing.Size(216, 194);
            this.CompraYImpresion.TabIndex = 6;
            this.CompraYImpresion.Text = "Comprar";
            this.CompraYImpresion.UseVisualStyleBackColor = false;
            this.CompraYImpresion.Click += new System.EventHandler(this.CompraYImpresion_Click);
            // 
            // BotonTarifa
            // 
            this.BotonTarifa.BackColor = System.Drawing.Color.Wheat;
            this.BotonTarifa.Location = new System.Drawing.Point(37, 570);
            this.BotonTarifa.Name = "BotonTarifa";
            this.BotonTarifa.Size = new System.Drawing.Size(220, 194);
            this.BotonTarifa.TabIndex = 5;
            this.BotonTarifa.Text = "Tarifa";
            this.BotonTarifa.UseVisualStyleBackColor = false;
            this.BotonTarifa.Click += new System.EventHandler(this.BotonTarifa_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::AppVuelosCR.Properties.Resources.airplane_fly_travel_icon_icons_com_51074;
            this.pictureBox1.Location = new System.Drawing.Point(621, 47);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(312, 331);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // comboBoxAerolinea
            // 
            this.comboBoxAerolinea.FormattingEnabled = true;
            this.comboBoxAerolinea.Items.AddRange(new object[] {
            "Avianca",
            "Despegar",
            "American Airlines",
            "Japan Airlines",
            "Qatar Airways"});
            this.comboBoxAerolinea.Location = new System.Drawing.Point(200, 390);
            this.comboBoxAerolinea.Name = "comboBoxAerolinea";
            this.comboBoxAerolinea.Size = new System.Drawing.Size(233, 49);
            this.comboBoxAerolinea.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 398);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(188, 41);
            this.label3.TabIndex = 2;
            this.label3.Text = "Aerolineas:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 298);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(156, 41);
            this.label2.TabIndex = 1;
            this.label2.Text = "Destinos:";
            // 
            // comboBoxDestinos
            // 
            this.comboBoxDestinos.FormattingEnabled = true;
            this.comboBoxDestinos.Items.AddRange(new object[] {
            "Argentina",
            "Bolivia",
            "Brasil",
            "Chile",
            "Colombia",
            "Ecuador",
            "Guyana",
            "Nicaragua "});
            this.comboBoxDestinos.Location = new System.Drawing.Point(168, 290);
            this.comboBoxDestinos.Name = "comboBoxDestinos";
            this.comboBoxDestinos.Size = new System.Drawing.Size(208, 49);
            this.comboBoxDestinos.TabIndex = 0;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Crimson;
            this.button3.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(12, 1120);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(82, 33);
            this.button3.TabIndex = 2;
            this.button3.Text = "Salir";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Wheat;
            this.ClientSize = new System.Drawing.Size(1125, 1165);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "VuelosCR";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxDestinos;
        private System.Windows.Forms.ComboBox comboBoxAerolinea;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button CompraYImpresion;
        private System.Windows.Forms.Button BotonTarifa;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBoxCedula;
        private System.Windows.Forms.TextBox textBoxNombre;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelPrecioFinal;
        private System.Drawing.Printing.PrintDocument printDocument1;
    }
}

