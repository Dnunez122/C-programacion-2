﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VuelosCR.Model
{
    public class Cliente
    {
        public string Cedula {  get; set; }
        public string Nombre { get; set; }
    }

    public class Tiquete
    {
        public Cliente Cliente { get; set; }
        public string Destino { get; set; }
        public string Aerolinea { get; set; }

        public decimal CalcularMontoServicio(decimal precioBase)
        {
            decimal porcentaje = 0m;
            switch (Aerolinea)
            {
                case "Avianca": porcentaje = 0.24m; break;
                case "Despegar": porcentaje = 0.18m; break;
                case "American Airlines": porcentaje = 0.32m; break;
                case "Japan Airlines": porcentaje = 0.25m; break;
                case "Qatar Airways": porcentaje = 0.27m; break;
            }
            return precioBase * porcentaje;
        }

        public decimal CalcularMontoIVA(decimal subtotal)
        {
            return subtotal * 0.13m;
        }

        public decimal CalcularPrecioFinalTiquete(decimal precioBase)
        {
            decimal servicio = CalcularMontoServicio(precioBase);
            decimal subtotal = precioBase + servicio;
            decimal iva = CalcularMontoIVA(subtotal);
            return subtotal + iva;
        }
    }
}
