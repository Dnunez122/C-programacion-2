﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppVuelosCR
{
    internal class Cliente
    {

        //atributos 
        public string Cedula { get; set; }
        public string Nombre { get; set; }

      

    }
}
