﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VuelosCR.DAL
{
    public class AuthManager
    {
        private static string dataBase = "Server=.\\SQLExpress;Database=DbTiquetes;User ID=VuelosCR;Password=1234;TrustServerCertificate=true;";
        public static bool Login(string email, string password)
        {
            using (SqlConnection connection = new SqlConnection(dataBase))
            {
                string query = "SELECT COUNT(*) FROM usuarios WHERE email = @Email AND password = @Password";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", email);
                command.Parameters.AddWithValue("@Password", password);

                try
                {
                    connection.Open();
                    int count = (int)command.ExecuteScalar();
                    return count > 0;
                }
                catch (Exception ex)
                {
                    // Manejo de la excepción
                    return false;
                }
            }
        }
    }
}