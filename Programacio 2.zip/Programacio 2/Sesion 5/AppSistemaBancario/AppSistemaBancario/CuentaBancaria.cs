﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSistemaBancario
{
   
    /// estructura del class object
    
    public class CuentaBancaria
    {
        //Propiedades, verbos Set (asignar) / Get (obtener)
         public string NumeroCuenta { get; set; }

        public string NombreCliente { get; set; }

        public float Saldo { get; set; }

        public string TelefonoCliente { get; set; }

        //Constructor por omision  para inicializar los atributos 

        public CuentaBancaria()
        {
            //inicializa sus propiedades 

            NumeroCuenta = "201-4596-2";
            NombreCliente = "Diego Núñez Calderón";
            Saldo = 0;
            TelefonoCliente = "8494-9678";

        }

        public void Deposito(float monto)
        {
            Saldo = Saldo + monto;
        }

        public void Retiro(float monto)
        {
            Saldo = Saldo - monto;
        }

        //Metodo encargado de validar si hay saldo en la cuenta, si si regresa bool true
        public bool TienesSaldo(float monto)
        {
            bool conSaldo = false; //Declaro variable local

            if (Saldo >= monto)  //Se valida saldo
            {
                conSaldo = true; //Se indica si hay saldo 
            }
            return conSaldo; //Se retorna la varibale control 
        }








    } ///Cierre class
} ///cierre de namespace
