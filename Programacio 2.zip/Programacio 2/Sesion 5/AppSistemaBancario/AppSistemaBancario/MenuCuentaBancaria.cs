﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace AppSistemaBancario
{
    public class MenuCuentaBancaria
    {

        //Variable tipo objeco CuentaBancaria
        private CuentaBancaria objCuentaCanc = null;




        //Constructor por omision 
        public MenuCuentaBancaria()
        {
            //Importante siempre instanciar objeto
            objCuentaCanc = new CuentaBancaria();

            //Se usa para ver el menu 
            MostraMenu();
        }

        private void MostraMenu()
        {
            string menuOpciones = "***Opciones menú***";
            menuOpciones += "1.Retiro efectivo.\n";
            menuOpciones += "2. Deposito en la cuenta\n";
            menuOpciones += "3.Modificar telefono cliente\n";
            menuOpciones += "4. Mostrar informacion cliente\n";
            menuOpciones += "5.Salir\n";
            menuOpciones += "Digite una opcion\n";

            int opcion = 0;
            do
            {
                //Se muestra el menu 
                Console.WriteLine(menuOpciones);

                opcion = int.Parse(Console.ReadLine()); //Lee valor ingresado 

                switch (opcion)
                {
                    //retiro efectivo
                    case 1:
                        Retiroefectivo();
                        break;
                    //deposito
                    case 2:
                        DepositarEfectivo();
                        break;
                    //Modificar telefono
                    case 3:
                        string telf = String.Empty;
                        Console.WriteLine("Digite el nuevo numero de telefono: ");
                        telf = Console.ReadLine();
                        ModificarTelefono(telf);
                        Console.WriteLine("Telefono actualizado correctamente...");
                        break;
                    //mostrar informacion 
                    case 4:
                        MostrarInformacion();
                        break;
                    //salir 
                    case 5:
                        break;


                }


            } while (opcion != 5);//Condicion de salida, termina asi la opcion es 5

        }

        private void Retiroefectivo()
        {
            float monto = 0;
            Console.WriteLine("Digite el monto a retirar: ");
            monto = float.Parse(Console.ReadLine());   //Se lee y se convierte en un tipo de dato float 

            if (objCuentaCanc.TienesSaldo(monto))
            {
                objCuentaCanc.Retiro(monto);
                Console.WriteLine("Retiro de efectivo realizado...");
            }
            else
            {
                Console.WriteLine($"Fondos insuficientes en cuenta {objCuentaCanc.NumeroCuenta}\n" +
                    $"un saldo de {objCuentaCanc.Saldo}");

            }


          


        }

        private void DepositarEfectivo()
        {
            float monto = 0;
            Console.WriteLine("Digite monto a depositar:");
            monto = float.Parse(Console.ReadLine());




        }


        private void MostrarInformacion()
        {
            
                Console.WriteLine("Datos del cliente\n");
                Console.WriteLine($"Nombre del cliente {objCuentaCanc.NombreCliente}\n" +
                    $"numero de cuenta {objCuentaCanc.TelefonoCliente}" +
                    $"{objCuentaCanc.Saldo} telefono ");
            
        }



        private void ModificarTelefono(string pTelf)
        {
            objCuentaCanc.TelefonoCliente = pTelf;
        }
    
    
    }//Cierre de clase
} //Cierre namespace
