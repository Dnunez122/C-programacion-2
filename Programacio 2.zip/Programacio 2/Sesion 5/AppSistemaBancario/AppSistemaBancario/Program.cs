﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSistemaBancario
{
    internal class Program
    {

    
        
        
        
        /// Metodo encargado de ejecutar toda la 
        static void Main(string[] args)
        {
            //Variable tipo objetc PrincipalCuentaBancaria
            PrincipalCuentaBancaria objPrincipalCuenta;

            //Siempre se instancia 
            objPrincipalCuenta = new PrincipalCuentaBancaria();

            //Se finaliza el app

            Console.WriteLine("Presione cualquier tecla finalizar...");
            Console.ReadKey();
            Environment.Exit(0);

        }
    }
}
