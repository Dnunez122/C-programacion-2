﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VuelosCR.Model;

namespace VuelosCR.Interfaz
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }

        private void Principal_Load(object sender, EventArgs e)
        {
            // Alimentar ComboBox de Destinos
            cmbDestino.Items.Add("Argentina");
            cmbDestino.Items.Add("Bolivia");
            cmbDestino.Items.Add("Brasil");
            cmbDestino.Items.Add("Chile");
            cmbDestino.Items.Add("Colombia");
            cmbDestino.Items.Add("Ecuador");
            cmbDestino.Items.Add("Guyana");
            cmbDestino.Items.Add("Nicaragua");

            // Alimentar ComboBox de Aerolíneas
            cmbAerolinea.Items.Add("Avianca");
            cmbAerolinea.Items.Add("Despegar");
            cmbAerolinea.Items.Add("American Airlines");
            cmbAerolinea.Items.Add("Japan Airlines");
            cmbAerolinea.Items.Add("Qatar Airways");
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                var cliente = new Cliente
                {
                    Cedula = txtCedula.Text,
                    Nombre = txtNombre.Text,
                };
                var Tiquete = new Tiquete
                {
                    Cliente = cliente,
                    Destino = cmbDestino.SelectedItem.ToString(),
                    Aerolinea = cmbAerolinea.SelectedItem.ToString(),
                };
                decimal precioBase = ObtenerPrecioDestino(Tiquete.Destino);
                decimal precioFinal = Tiquete.CalcularPrecioFinalTiquete(precioBase);
                lbPrecioFinal.Text = $"El precio final del tiquete es : ${precioFinal}";


            }
            catch
            {

            }
        }

        private decimal ObtenerPrecioDestino(string destino)
        {
            switch (destino)
            {
                case "Argentina": return 200m;
                case "Bolivia": return 250m;
                case "Brasil": return 325m;
                case "Chile": return 275m;
                case "Colombia": return 205m;
                case "Ecuador": return 230m;
                case "Guyana": return 270m;
                case "Nicaragua": return 120m;
                default: return 0m;
            }
        }

        private void btnComprar_Click(object sender, EventArgs e)
        {

        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCedula_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
