﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Porcentaje_de_alimentacion
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ///declaramos variables.
            int salario = 0;
            double porcentaje_comida = 0;
            double resultado = 0;
            string dato = "";


            ////Pedimos info 
            Console.WriteLine("Digite su salario mensual: ");
            dato = Console.ReadLine();
            salario = int.Parse(dato);

            Console.WriteLine("¿Cuanto gasta en alimentación?");
            dato = Console.ReadLine();
            porcentaje_comida = double.Parse(dato);

            ///Declaramos operaciones matematicas
            resultado = (porcentaje_comida / salario) * 100;

            ///Mostramos le resultado.
            Console.WriteLine("El porcentaje que se usa de su salario en alimentacion es: " + resultado+ "%");


            ///Cerramos
            Console.WriteLine("Presione tecla para terminar.");
            Console.ReadKey();
            Environment.Exit(0);
        }
    }
}
