﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contrasena
    {
        internal class Program
        {
            static void Main(string[] args)
            {
                string contraseña = "478596";
                string dato = "";

                Console.WriteLine("***Telefono Diego***");

                for (int i = 0; i < 3; i++)
                {
                    Console.WriteLine("Ingrese la contraseña: ");
                    dato = Console.ReadLine();

                    if (dato == contraseña)
                    {
                        Console.WriteLine("Ingreso con éxito.");
                        Console.WriteLine("Presione cualquier tecla para salir.");
                        Console.ReadKey();
                        Environment.Exit(0);
                    }
                    else
                    {
                        Console.WriteLine("Acceso Denegado. Intento " + (i + 1) + " de 3.");
                    }
                }

                Console.WriteLine("Se han agotado los intentos. Presione cualquier tecla para salir.");
                Console.ReadKey();
            }
        }
    }



    

