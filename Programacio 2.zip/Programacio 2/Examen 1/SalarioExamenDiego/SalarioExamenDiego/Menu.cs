﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalarioExamenDiego
{
    internal class Menu
    {

       
        public void MostrarMenu()
        {


            // Instancia para poder usar el método de salario aquí en el menú
            Empleado empleado = new Empleado();

            // Variable de control para el ciclo
            char opcion;
            do
            {
                // Llamamos al método de la clase Empleado
                empleado.ObtenerSalarioBrutoYNeto();

                // Pedimos al usuario que presione "S" para hacer otro cálculo o cualquier otra tecla para terminar
                Console.WriteLine("Presione la tecla S para hacer otro cálculo, o cualquier otra tecla para terminar.");



                // Leemos la tecla ingresada por el usuario
                opcion = Console.ReadKey().KeyChar;

                // Agregamos un salto de línea después de leer la tecla
                Console.WriteLine();

            } while (opcion == 'S' || opcion == 's'); // Continuar el ciclo mientras la tecla ingresada sea 'S' o 's'

            // Finalizar la aplicación
            Console.WriteLine("Presione cualquier tecla para terminar.");
            Console.ReadKey();


        }




    }
}
