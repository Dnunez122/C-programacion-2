﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppVuelosCR
{
    public partial class Login : Form
    {


        //conexion  con sql 
        SqlConnection conexion = new SqlConnection("server = .\\SQLExpress; Database = DbTiquetes; User id = UserExamenUH; Password = UH2024; TrustServerCertificate = true");

        public Login()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //se abre la conexion
            conexion.Open();
            
           
            //string para consultar los datos y ver si son iguales con los de sql
            string consulta = "select * from Usuario where Login= '"+ textBoxLogin.Text+ "'  and Password = '"+ textBoxPassword.Text+"'";


            //se instancia el comando 
            SqlCommand comando = new SqlCommand(consulta, conexion);


            //el comando que nos va a permitir leer la informacion de sql 
            SqlDataReader lector; 
            lector = comando.ExecuteReader();


            //si lector tiene coincidencias 
            if (lector.HasRows == true ) 
            {
                //mensaje de bienvenida 
                MessageBox.Show("Bienvenido.");

                //se instancia el forms principal
                Form1 form1 = new Form1();

                form1.Show();

                this.Hide();


            }
            else
            {
                //Sino, mensaje de error 
                MessageBox.Show("Credenciales incorrectos. ");
            }

            //se cierra la conexion
            conexion.Close();




        }


        public partial class LoginForm : Form
        {
            // Variable para indicar si el inicio de sesión fue exitoso
            public static bool LoginSuccessful = false;

            private void btnLogin_Click(object sender, EventArgs e)
            {
                // Aquí iría la lógica para verificar las credenciales de inicio de sesión
                // Si el inicio de sesión es exitoso, establecer LoginSuccessful en true
                LoginSuccessful = true;

                // Cerrar el formulario de inicio de sesión
                this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
