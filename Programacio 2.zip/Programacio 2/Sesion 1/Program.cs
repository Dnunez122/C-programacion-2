﻿using System;
using System.ComponentModel.Design;

class Program
{
    static void Main()
    {
        Console.WriteLine("Digita un numero: ");
        string num1 = Console.ReadLine();

        


    }
}