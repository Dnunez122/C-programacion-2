﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculadoraIMC
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Variables 
            double altura = 0;
            double peso = 0;
            double IMC_ = 0;
            double IMC_TOTAL = 0;
            int exponente = 2;
            string dato = "";


            //Inicio y pedido de datos 
            Console.WriteLine("***Calculadora IMC***");

            Console.WriteLine("Ingrese su altura: ");
            dato = Console.ReadLine();
            altura = double.Parse(dato);


            Console.WriteLine("Ingrese su peso: ");
            dato = Console.ReadLine();
            peso = double.Parse(dato);

            IMC_ = Math.Pow(altura, 2);

            IMC_TOTAL = peso / IMC_;


            ///Ciclo if pq no supe usar el swtich para esto xd 
            if (IMC_TOTAL < 18.5)
            {
                Console.WriteLine("Estás bajo peso (delgadez) " + IMC_TOTAL);
            }
            else if (IMC_TOTAL >= 18.5 && IMC_TOTAL < 25.0)
            {
                Console.WriteLine("Estás en peso normal (saludable) " +IMC_TOTAL);
            }
            else if (IMC_TOTAL >= 25.0 && IMC_TOTAL < 30.0)
            {
                Console.WriteLine("Estás en sobrepeso" + IMC_TOTAL);
            }
            else if (IMC_TOTAL >= 30.0 && IMC_TOTAL < 35.0)
            {
                Console.WriteLine("Estás en obesidad grado I (Moderada obesidad)" + IMC_TOTAL);
            }
            else if (IMC_TOTAL >= 35.0 && IMC_TOTAL < 40.0)
            {
                Console.WriteLine("Estás en obesidad grado II (Obesidad severa)" + IMC_TOTAL);
            }
            else if (IMC_TOTAL >= 40.0)
            {
                Console.WriteLine("Estás en obesidad grado III (Obesidad mórbida)." + IMC_TOTAL);
            }
            ///Cerrar
            Console.WriteLine("Presiona cualquier tecla para salir.");
            Console.ReadKey();
            Environment.Exit(0);
        }
    }
}
