﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sueldo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /// Declaramos variables.
            int Horas_semanales = 0;
            double Salario_hora = 0;
            double Deduccion_Caja = 0.105;
            double Deduccion_Asociacion = 0.05;
            string Input = "";

            /// Pedimos info y cambiamos el tipo de variables
            Console.WriteLine("Digite el numero de horas trabajadas por semana: ");
            Input = Console.ReadLine();
            Horas_semanales = int.Parse(Input);

            Console.WriteLine("Digite su salario por hora: ");
            Input = Console.ReadLine();
            Salario_hora = double.Parse(Input); // Cambio a double

            /// Resultados.
            double Salario_bruto = Horas_semanales * Salario_hora;

            // Aplicar deducciones
            double deduccionCaja = Salario_bruto * Deduccion_Caja;
            double deduccionAsociacion = Salario_bruto * Deduccion_Asociacion;
            double totalDeducciones = deduccionCaja + deduccionAsociacion;

            // Salario mensual después de deducciones
            double Salario_mensual = Salario_bruto - totalDeducciones;

            /// Mostramos resultados
            Console.WriteLine("El salario mensual de esta persona es de: " + Salario_mensual.ToString("C"));

            /// Cerramos 
            Console.WriteLine("Presione una tecla para cerrar.");
            Console.ReadKey();
        }
    }
}
