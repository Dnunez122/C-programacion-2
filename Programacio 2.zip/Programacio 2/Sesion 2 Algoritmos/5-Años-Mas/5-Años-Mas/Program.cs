﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5_Años_Mas
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ///Declaramos variables
            double edad = 0;
            string dato = "";
            double edad_futura = 0;

            ///Pedimos info y cambiamos tipo de dato 
            Console.WriteLine("¿Cuantos años tiene actualmente? ");

            dato = Console.ReadLine();

            edad = double.Parse(dato);

            ///Declaramos resultado de edad futura
            edad_futura = edad + 5;

            ///mostramos el resutlado de su edad futura
            Console.WriteLine("Dentro de 5 años, tendrá: " +edad_futura);

            Console.WriteLine("Presione cualquier tecla para terminar. ");
            Console.ReadKey();
            Environment.Exit(0);

        }
    }
}
